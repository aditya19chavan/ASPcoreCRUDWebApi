﻿using ASPCoreWebApiCRUD.Data;
using ASPCoreWebApiCRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ASPCoreWebApiCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : Controller
    {
        private readonly StudentdbContext studentDbContext;

        public StudentController(StudentdbContext studentDbContext)
        {
            this.studentDbContext = studentDbContext;
        }
        [HttpPost]
        [Route("/add")]
        public async Task<IActionResult> addStudent(Student student)
        {
            await studentDbContext.Students.AddAsync(student);
            await studentDbContext.SaveChangesAsync();
            return Ok(student);
        }

        [HttpGet]
        [Route("/students")]
        public async Task<IActionResult> allStudents()
        {
            return Ok(await studentDbContext.Students.ToListAsync());
        }

        [HttpGet]
        [Route("/{id}")]
        public async Task<IActionResult> getStudentById([FromRoute] int id)
        {
            try
            {
                Student foundStudent = await studentDbContext.Students.FindAsync(id);
                if (foundStudent == null)
                {
                    return NotFound();
                }
                return Ok(foundStudent);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut]
        [Route("/update/{id}")]
        public async Task<IActionResult> updateStudentById([FromRoute] int id, Student updatedStudent)
        {
            Student foundStudent = await studentDbContext.Students.FindAsync(id);
            if (foundStudent != null)
            {
                foundStudent.name = updatedStudent.name;
                foundStudent.pecentage = updatedStudent.pecentage;
                await studentDbContext.SaveChangesAsync();
                return Ok(foundStudent);
            }
            return NotFound();
        }

    
       [HttpDelete]
        [Route("/delete/{id}")]
        public async Task<IActionResult> deleteStudentById([FromRoute] int id)
        {
            Student foundStudent = await studentDbContext.Students.FindAsync(id);
            if (foundStudent != null)
            {
                studentDbContext.Remove(foundStudent);
                await studentDbContext.SaveChangesAsync();
                return Ok("Student deleted of id: " + id);
            }
            return NotFound();
        }
    }

}
