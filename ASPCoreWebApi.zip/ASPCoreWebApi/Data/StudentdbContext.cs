﻿using ASPCoreWebApiCRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace ASPCoreWebApiCRUD.Data
{
    public class StudentdbContext : DbContext
    {
        public StudentdbContext(DbContextOptions options) : base(options)
        {


        }
        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }

    } 
}
