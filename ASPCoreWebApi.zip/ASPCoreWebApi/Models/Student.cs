﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ASPCoreWebApiCRUD.Models
{
    [Table("student_master")]
    public class Student
    {
        [Key]
        public int  id { get; set; }

      [Required]
    public string name { get; set; }

        public double pecentage {  get; set; }

        public DateTime dob { get; set; }
    }
}
